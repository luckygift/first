package com.yuri;



import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

import java.io.*;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//import java.Strict.Math;

public class Controller {
    public Controller() {}

    @FXML
    public Pane paneSample;

    @FXML
    public Button buttonContour;

    @FXML
    public Button buttonDraw;
//    @FXML
//    public Pane paneMain;

    @FXML
    public Slider sliderRight;
    @FXML
    public Slider sliderLift;
    @FXML
    public Slider sliderLower;
    @FXML
    public Slider sliderLowerSec;
    @FXML
    public Slider sliderRightSec;
    @FXML
    public TextField tFScale;
    @FXML
    public TextField tFTileWidth;
    @FXML
    public TextField tFTileHeight;
    @FXML
    public TextField tFTileSeam;

    //tileWidth - ширина плитки-мм
    private int tileWidth = 100;

    //tileHeight - высота плитки-мм
    private int tileHeight = 300;


    // tileSeam - ширина шва-мм
    private int tileSeam = 10;

    // biasX смещение по Х-мм
    private int biasX = 7;

    // biasY смещение по Y-мм
    private int biasY = 5;

    // scale - масштаб
    // 0.001 - 10
    private float scale = 1.0F;

    //angleRotation - угол поворота-рад
    //0<angleRotation <=1.57 !!- угол поворота-рад
    private double angleRotation = 0;


    // sRS - Семафор для обработчика. открывается один раз при запуске первого слушателя.
    // Дальше - всех новых слушателей пропускает без остановки! обработки

    // public static  int sRS = 0;

//    GridP gridP = new GridP();

   public ParamGrid paramGrid = new ParamGrid();
   // paramGrid.getInstance();

    long carentDataTime;
      // - текущее время в милисекундах

    public static int sRS = 0;

    public static int sLSA = 0;

    public static int sRSA = 0;

    long fixDataTimesRS = 0;

     // Параметры контура
    public  ElementsCollection elementsCollection = ElementsCollection.getInstance();

    Element element = new Element(0, 0F);

    private ElementsCollectionSave elementsCollectionSave = ElementsCollectionSave.getInstance();

     // Габаритные размеры контура
    int maxContourX = 0;
    int maxContourY = 0;
    float scalePaneSample = 1;

     // Реальные размеры панели окна Sample
    int paneSampleXReal = 738;
    int paneSampleYReal = 540;

     // Реальные размеры второго окна
    int secondWindowXReal = 1216;
    int secondWindowYReal = 889;

     // Смещение изображения второго окна в панели первого
    public int startPointXNew = 0;
    public int startPointYNew = 0;

     // Смещение отображения второго окна в панели первого
    public int startPointXprom = 0;
    public int startPointYprom = 0;

     // Смещение отображения контура помещения во втором окне
     public int startPointXSecWin = 0;
     public int startPointYSecWin = 0;

    // Переменные проверки валидноси

    private String pattern;
    private Pattern r;
    private Matcher m;

    private WindowErrorNumberFormat windowErrorNumberFormat = new WindowErrorNumberFormat();


    // Параметры смещения контура помещения относительно 0 во втором окне SecondWindow

    StartPointElementsCollection startPointElementsCollection = StartPointElementsCollection.getInstance();

    // Флаг включения слайдеров

     protected int flagSlider = 0;


    public void sliderRightAction(Event event) {

        if (flagSlider == 1) {

        carentDataTime = System.currentTimeMillis();
        if (carentDataTime >= fixDataTimesLS + 500) {

            fixDataTimesRS = carentDataTime;

        if (sRS == 0) {
            sRS = 1;


            System.out.println("  sliderRight " + sliderRight.valueProperty());

            sliderRight.valueProperty().addListener(new ChangeListener<Number>() {
                                                        // @Override

                                                        public void changed(ObservableValue<? extends Number> ov,
                                                                           Number oldValue, Number newValue) {

                                                            System.out.println("\n Правый слайдер " + newValue.intValue());
                                                            System.out.println("\n Правый слайдер sRS " + sRS);
//
//                                                            // biasX01 - коэффициент смещения правого слайдера
                                                 //           double biasX01 = (gridP.getTileWidth() + gridP.getTileSeam()) * gridP.getScale() / 100;

//                                                                       double biasX01 = (tileWidth + tileSeam) * scale / 100;
                                                                    double biasX01 = (tileWidth + tileSeam) * scale / 100;

//
//                                                            //gridP.setBiasX((gridP.getTileWidth()/100)*newValue.intValue());
                                              //              gridP.setBiasX((int) (newValue.intValue() * biasX01));
                                                                       biasX = ((int) (newValue.intValue() * biasX01));
                                              //               System.out.println("AA BiasX:  " + gridP.getBiasX());

//                                                            // Временная задержка - не нужна? при срабатывании слайдера создается новый слушатель -?
//                                                            // его необходимо выключать!!
//                                                            // TimeUnit.SECONDS.toMillis(50);
//                                                            gridP.makeGridDraw();
//
//                                                            // слушатель вновь не открывается для обработки!!

//
//
                                                        }
                                                    });


 //           );
//        } else {
        }
 //      ;

        System.out.println("\n sliderRightAction ");
        saveParamGrid();
        SecondWindow secondWindow = new SecondWindow();
        try {
            secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                         paramGrid,
                                         elementsCollection,
                                         StartPointElementsCollection.getInstance());
        } catch (IOException e) {
            e.printStackTrace();
        }

        //TimeUnit.SECONDS.toMillis(500);
       // sRS=0;  !!! - не обнулять - !!!

    }
}
    }

    public static int sLS = 0;



    long fixDataTimesLS = 0;

    public void sliderLowerAction(Event event) {

        if (flagSlider == 1){

        carentDataTime = System.currentTimeMillis();
        if (carentDataTime >= fixDataTimesLS + 500) {

            fixDataTimesLS = carentDataTime;



            if (sLS == 0) {
                sLS = 1;
                System.out.println("\n  Нижний слайдер " + sliderLower.valueProperty());

                sliderLower.valueProperty().addListener(new ChangeListener<Number>() {
                    // @Override
                    public void changed(ObservableValue<? extends Number> ov,
                                        Number oldValue, Number newValue) {
                        System.out.println("\n Нижний слайдер " + newValue.intValue());

                        // biasY01 -коэффициент смещения нижнего слайдера
                        //       double biasY01 = (gridP.getTileHeight() + gridP.getTileSeam()) * gridP.getScale() / 100;
                        // /100
                        double biasY01 = (tileHeight + tileSeam) * scale / 100;
//                    // bY = newValue.intValue();
//
//                    // setBiasX((int) newValue);// setBiasX(int biasX)
//                    // GridP gridP = new GridP (newValue.intValue(),0);
//                    // GridP gridP = new GridP();

                        //        gridP.setBiasY((int) (newValue.intValue() * biasY01));

                        biasY = ((int) ((-newValue.intValue()) * biasY01));
//                    gridP.makeGridDraw();
//                    //GridP.setBiasX(fX );

                        System.out.println("sliderLower " + biasY);


                    }
                });


//        } else {
//        }
            } ;

            System.out.println("sliderLowerAction ");
            saveParamGrid();
            SecondWindow secondWindow = new SecondWindow();
            try {
                secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                             paramGrid,
                                             elementsCollection,
                                             StartPointElementsCollection.getInstance());
            } catch (IOException e) {
                e.printStackTrace();
            }
            //sLS = 0; !!! - не обнулять - !!!
        }
    }}

    long fixDataTimesLiS =0;
    public static int sLiS = 0;

    public void sliderLiftAction(Event event) {

        if (flagSlider == 1){

        carentDataTime = System.currentTimeMillis();
        if (carentDataTime >= fixDataTimesLiS + 500) {

            fixDataTimesLiS = carentDataTime;

            if (sLiS == 0) {
                sLiS = 1;
                System.out.println("\n  Левый слайдер " + sliderLift.valueProperty());

                sliderLift.valueProperty().addListener(new ChangeListener<Number>() {
                    // @Override
                    public void changed(ObservableValue<? extends Number> ov,
                                        Number oldValue, Number newValue) {

                        System.out.println("\n Левый слайдер " + newValue.intValue());

                        angleRotation = (0.0157 * newValue.intValue());

                        System.out.println("Левый слайдер " + 0.0157 * newValue.intValue());

                        System.out.println("angleRotation " + angleRotation);


                    }
                });

            } else {
            }
            ;

            System.out.println("\n sliderLiftAction ");


            // Передаем параметры в начальное смещение контура помещения по X, Y

            // StartPointElementsCollection startPointElementsCollection = StartPointElementsCollection.getInstance();
            // startPointElementsCollection.setStartPointElementsCollectionX(-startPointXSecWin);
            // startPointElementsCollection.setStartPointElementsCollectionY(-startPointYSecWin);

            saveParamGrid();



            SecondWindow secondWindow = new SecondWindow();
            try {
                secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                             paramGrid,

                                             elementsCollection,

                                             //elementsCollection,
                                             StartPointElementsCollection.getInstance());
            } catch (IOException e) {
                e.printStackTrace();
            }

           // sLiS = 0; !!! - не обнулять - !!!

        }
    }}

    public void tFScaleAction(ActionEvent actionEvent) {

        String d2String = tFScale.getText();

        // Проверка ввода формата float

        pattern = "[A-Za-zА-Яа-я]";
        r = Pattern.compile(pattern);
        m = r.matcher(d2String);

        if (!m.find()) {

            pattern = "^\\d+(\\u002E\\d+)?$";
            r = Pattern.compile(pattern);
            m = r.matcher(d2String);

            if (m.find()) {

                // Формат верный

                Float d2 = Float.valueOf(d2String);
                    System.out.println("  1 scale " + scale);

                if (d2 < 0.001) {
                    d2 = 0.001F;

                    scale = d2;
                        System.out.println("  2 scale " + scale);
                    tFScale.setText(String.valueOf(scale));

                    }
                      else { if (d2 > 10) {
                    d2 = 10.0F;

                    scale = d2;
                    tFScale.setText(String.valueOf(scale));
                    System.out.println("  3 scale " + scale);


                       }
                  else        { if (d2 <= 10) {
                    scale = d2;
                    tFScale.setText(String.valueOf(scale));
                    System.out.println("  4 scale " + scale);

                      }
                    }
                   }

            } else {

                System.out.println(" 1 Не верный формат ввода числа");
                windowErrorNumberFormat.show();

                   }


        }else{

            // Формат не верный

                System.out.println(" 00 Не верный формат ввода числа");
            windowErrorNumberFormat.show();

        }
    }

    public void tFTileWidthAction(ActionEvent actionEvent) {

        String d3String = tFTileWidth.getText();
        // Проверка ввода числового формата

        pattern = "\\D";
        r = Pattern.compile(pattern);
        m = r.matcher(d3String);

        if (m.find()) {

            // Формат не верный

            System.out.println("Не верный формат ввода числа");
            windowErrorNumberFormat.show();

        } else {

            pattern = "\\d";
            r = Pattern.compile(pattern);
            m = r.matcher(d3String);

            if (m.find()) {

                // Формат верный

                    System.out.println("\n Формат поля d3String правельный: " + d3String);
                Integer d3 = Integer.valueOf(d3String);
                    System.out.println("   d3:  " + d3);


                //Integer d3 = Integer.valueOf(d3String);
                     System.out.println("   tileWidth  " + d3);

                if (d3 < 30) {
                    d3 = 30;

                    tileWidth = d3;

                       System.out.println("   tileWidth  " + tileWidth);
                    tFTileWidth.setText(String.valueOf(d3));

                } else {
                    if (d3 > 500) {
                        d3 = 500;


                        tileWidth = d3;
                        tFTileWidth.setText(String.valueOf(d3));

                    } else {
                        tileWidth = d3;


                    }
                }
            }
        }
    }

    public void tFTileHeightAction(ActionEvent actionEvent) {
        String d4String = tFTileHeight.getText();

        // Проверка ввода числового формата

        pattern = "\\D";
        r = Pattern.compile(pattern);
        m = r.matcher(d4String);

        if (m.find()) {

            // Формат не верный

            System.out.println("Не верный формат ввода числа");
            windowErrorNumberFormat.show();

        } else {

            pattern = "\\d";
            r = Pattern.compile(pattern);
            m = r.matcher(d4String);

            if (m.find()) {

                // Формат верный

                    System.out.println("\n Формат поля d4String правельный: " + d4String);
                Integer d4 = Integer.valueOf(d4String);
                    System.out.println("   d4:  " + d4);


//        Integer d4 = Integer.valueOf(d4String);
                    System.out.println("   tileHeight  " + d4);

                if (d4 < 30) {

                    d4 = 30;

                    tileHeight = d4;

                       System.out.println("   tileHeight  " + d4);
                    tFTileHeight.setText(String.valueOf(d4));


                } else {
                    if (d4 > 500) {
                        d4 = 500;
                        tileHeight = d4;
                        tFTileHeight.setText(String.valueOf(d4));

                    } else {

                        tileHeight = d4;
                    }
                }
            }
        }
    }



    public void tFTileSeamAction(ActionEvent actionEvent) {
        String d5string = tFTileSeam.getText();

        // Проверка ввода числового формата

        pattern = "\\D";
        r = Pattern.compile(pattern);
        m = r.matcher(d5string);

        if (m.find()) {

            // Формат не верный

               System.out.println("Не верный формат ввода числа");

            windowErrorNumberFormat.show();

        } else {

            pattern = "\\d";
            r = Pattern.compile(pattern);
            m = r.matcher(d5string);

            if (m.find()) {

                // Формат верный

                   System.out.println("\n Формат поля d5string правельный: " + d5string);
                Integer d5 = Integer.valueOf(d5string);
                   System.out.println("   d5:  " + d5);

                if (d5 < 1) {
                    d5 = 1;
                    tileSeam = d5;
                       System.out.println("   tileSeam:  " + tileSeam);

                }else {if (d5 > 15) {
                    d5 = 15;
                    tileSeam = d5;
                       System.out.println("   tileSeam 01 скорректированный " + d5);
                    tFTileSeam.setText(String.valueOf(d5));

                      }else {
                          tileSeam = d5;
                             System.out.println("   tileSeam 02 не скорректированный " + d5);
                          tFTileSeam.setText(String.valueOf(d5));
                }



            }
        }
      }
    }

        @FXML
        public void initialize () {}


    public void buttonDrawAction(ActionEvent actionEvent) {

        flagSlider = 1;

        // Отрисовываем SecondWindow и paneSample

             System.out.println("\n   buttonDrawAction ");
//             System.out.println("\n    Размеры окна paneSample - Ширина  " + paneSample.getWidth());
//             System.out.println("\n    Размеры окна paneSample - Высота  " + paneSample.getHeight());


        // Передаем параметр слайдера в начальное смещение контура помещения по X

          // StartPointElementsCollection startPointElementsCollection = StartPointElementsCollection.getInstance();
        startPointElementsCollection.setStartPointElementsCollectionX(0);
        startPointElementsCollection.setStartPointElementsCollectionY(0);

        saveParamGrid();
           // Передаем параметры сетки в класс, их сохраняющий

          SecondWindow secondWindow = new SecondWindow();
        try {
            secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                         paramGrid,
                                         elementsCollection,
                                         StartPointElementsCollection.getInstance());

        } catch (IOException e) {
            e.printStackTrace();
        }



        //Подсчитываем габариты контура

        System.out. println("\n\n     secondWindowMethodElemCollec");


        // Углы u1*P рад u1*3.14
        float u1 = 0;
        float u2 = 0;
        float u3 = 0;

        // Длины предыдущего и последующего сегментов
        int dim1;
        int dim2;

        // абсолютные координаты текущей и следующей точек
          int x0 = 10;
          int y0 = 10;

        int x1 = 0;
        int y1 = 0;

        int x2 = 0;
        int y2 = 0;

        float PI = (float)Math.PI;;

        for (int i = 0; i < elementsCollection.size(); i++) {

            if (i==0) {

                dim1 = elementsCollection.get(i).getLength();


                   x1 =  x0 + dim1;
                   y1 =  y0;

;

                u2 = elementsCollection.get(i).getAngle();

                u1 = 1 - u2;

            }else {

                dim1 = elementsCollection.get(i).getLength();

                x1 = (int) (x1 + dim1 * (Math.cos(PI*u1)));
                y1 = (int) (y1 + dim1 * (Math.sin(PI*u1)));

                if (x2 < x1) x2 = x1;
                if (y2 < y1) y2 = y1;

                System.out.println(" Параметры контура x1 = " + x1 +
                                   "\n Параметры контура y1 = " + y1);



                u2 = elementsCollection.get(i).getAngle();

                u1 = u1 - u2 - 3 / 2;

            }
        }

         // Устанавливаем габариные размеры контура и масштаб для paneSample

                       System.out.println(" buttonDrawAction.Элементы коллекции elementsCollection: " + "\n " +
                                          elementsCollection);


                maxContourX = x2 + 30;
                maxContourY = y2 + 30;

                      System.out.println("\n Габариты контура " +
                                         "\n   maxContourX = " + maxContourX  +
                                         "\n   maxContourY = " + maxContourY);


         if ( paneSampleXReal > maxContourX &&
              paneSampleYReal > maxContourY )
              { scalePaneSample = 1;}
           else {
             float scalePaneSample1 = (float) maxContourX/paneSampleXReal;
             float scalePaneSample2 = (float) maxContourY/paneSampleYReal;

             if (scalePaneSample1 > scalePaneSample2) scalePaneSample = scalePaneSample1;
                else scalePaneSample = scalePaneSample2;

        }

        scalePaneSample = scalePaneSample*1.05f;

           // Устанавливаем масштаб во втором окне secondSample так же как и в paneSample

        // scale = scalePaneSample;

           // Прописываем масштаб на панели paneSample

        tFScale.setText(Float.toString(scale));

                System.out.println("\n Масштаб  scalePaneSample " + scalePaneSample);

        clearPaneSample();

        paneSampleMethodElemCollec(elementsCollection);

        RectangleDraw rectangleDraw = new RectangleDraw(0, 0);
         rectangleDraw.draw();
    }

    public void buttonContourAction(ActionEvent actionEvent) throws IOException {



        System.out.println("\n   buttonContourAction ");

        DialogWindow.getInstance();


    }

    public void saveParamGrid(){



        //tileWidth - ширина плитки-мм
        paramGrid.setTileWidth(tileWidth);
        //tileHeight - высота плитки-мм
        paramGrid.setTileHeight(tileHeight);
        // tileSeam - ширина шва-мм
        paramGrid.setTileSeam(tileSeam);
        // biasX смещение по Х-мм
        paramGrid.setBiasX(biasX);
        // biasY смещение по Y-мм
        paramGrid.setBiasY(biasY);
        // scale - масштаб
        // 0.001 - 10
        paramGrid.setScale(scale);
        //angleRotation - угол поворота-рад
        //0<angleRotation <=1.57 !!- угол поворота-рад
        paramGrid.setAngleRotation(angleRotation);

        System.out.println("\n angleRotation saveParamGrid  " + angleRotation);
        System.out.println("\n angleRotation     paramGrid " + paramGrid.getAngleRotation() +
                           "\n paramGrid.setTileWidth(tileWidth) " + paramGrid.getTileWidth() +
                           "\n paramGrid.setTileHeight(tileHeight) " + paramGrid.getTileHeight() +
                           "\n paramGrid.setTileSeam(tileSeam) " + paramGrid.getTileSeam() +
                           "\n paramGrid.setBiasX(biasX) " + paramGrid.getBiasX() +
                           "\n paramGrid.setBiasY(biasY) " + paramGrid.getBiasY() +
                           "\n paramGrid.setScale(scale) " + paramGrid.getScale());

    }

       // Слайдер (7) Смещение окна просмотра по X

    public void sliderLowerSecAction(Event event) {

        if (flagSlider == 1){

            carentDataTime = System.currentTimeMillis();
            if (carentDataTime >= fixDataTimesLS + 500) {

                fixDataTimesRS = carentDataTime;

                if (sLSA == 0) {
                    sLSA = 1;


                    System.out.println("  sliderLowerSec " + sliderLowerSec.valueProperty());

                    sliderLowerSec.valueProperty().addListener(new ChangeListener<Number>() {
                        // @Override

                        public void changed(ObservableValue<? extends Number> ov,
                                            Number oldValue, Number newValue) {

                            System.out.println("\n Нижний второй слайдер " + newValue.intValue());
                            System.out.println("\n Нижний второй слайдер sLSA " + sLSA);

                            //   Передаем параметр слайдера в начальное смещение контура помещения по X в окно paneSample

                           // startPointXNew = (int) (newValue.intValue()*(paneSampleXReal - secondWindowXReal/(scalePaneSample*scale))/100);
                           // startPointXNew = (int) (newValue.intValue()*((maxContourX - paneSampleXReal)/(scalePaneSample*scale))/100);

                            // Вычисляем смещение отрисовкаи контура второго окна в панели PaneSample главного окна

                            float parallaxX = (maxContourX / scalePaneSample)-(secondWindowXReal/(scale * scalePaneSample));
                            if (parallaxX < 0) parallaxX = 0;
                            startPointXNew = (int) (newValue.intValue()* parallaxX/100);




                            System.out.println("\n maxCounterX = " + maxContourX +
                                               "\n scalePaneSample = " + scalePaneSample +
                                               "\n maxContourX / scalePaneSample = " + maxContourX / scalePaneSample +
                                               "\n secondWindowXReal = " + secondWindowXReal +
                                               "\n scale = " + scale +
                                               "\n paneSampleXReal = " + paneSampleXReal

                                               );

//                                                            // Временная задержка - не нужна? при срабатывании слайдера создается новый слушатель -?
//                                                            // его необходимо выключать!!
//                                                            // TimeUnit.SECONDS.toMillis(50);//
//                                                            // слушатель вновь не открывается для обработки!!

                            // Передаем параметр слайдера в начальное смещение контура помещения по X во второе окно secondWindow

                             //startPointXSecWin = (int) (newValue.intValue()*(maxContourX - secondWindowXReal/(scalePaneSample*scale))/100);

                            float parallaxX2 = (maxContourX * scale) - secondWindowXReal;
                            if (parallaxX2 < 0) parallaxX2 = 0;

                            startPointXSecWin = (int) (newValue.intValue()*parallaxX2/100);

                            //StartPointElementsCollection startPointElementsCollection = StartPointElementsCollection.getInstance();
                            startPointElementsCollection.setStartPointElementsCollectionX(-startPointXSecWin);

                            saveParamGrid();
                            // Передаем параметры сетки в класс, их сохраняющий

                            // Перерисовываем второе окно SecondWindow

                            SecondWindow secondWindow = new SecondWindow();
                            try {
                                secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                                             paramGrid,
                                                             elementsCollection,
                                                             StartPointElementsCollection.getInstance());

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }




                //TimeUnit.SECONDS.toMillis(500);
                // sRS=0;  !!! - не обнулять - !!!

            }


           // Стираем панель PaneSample
        clearPaneSample();


          // Передаем контур помещения для отрисовки в PaneSample
        paneSampleMethodElemCollec(elementsCollection);

          // Передаем параметры startPointXNew - начальной точки отрисовки по Х и
          // scalePaneSample - масштаб отрисовки прямоугольника SecondWindow в панели PaneSample
        RectangleDraw rectangleDraw = new RectangleDraw(startPointXNew, scalePaneSample);
        rectangleDraw.setStartPointX(startPointXNew);
        startPointXprom = startPointXNew;
        rectangleDraw.draw();


    }}

       // Слайдер (4) Смещение окна просмотра по Y

    public void sliderRightSecAction(Event event) {

        if (flagSlider == 1) {

        carentDataTime = System.currentTimeMillis();
        if (carentDataTime >= fixDataTimesLS + 500) {

            fixDataTimesRS = carentDataTime;

            if (sRSA == 0) {
                sRSA = 1;


                System.out.println("  sliderRightSec " + sliderRightSec.valueProperty());

                sliderRightSec.valueProperty().addListener(new ChangeListener<Number>() {
                    // @Override

                    public void changed(ObservableValue<? extends Number> ov,
                                        Number oldValue, Number newValue) {

                        System.out.println("\n Правый второй слайдер " + newValue.intValue());
                        System.out.println("\n Правый второй слайдер sRSA = " + sRSA);

                        // Вычисляем смещение по Y

                        float parallaxY = (maxContourY / scalePaneSample)-(secondWindowYReal/(scale * scalePaneSample));
                        if (parallaxY <0) parallaxY = 0;

                        startPointYNew = (int) (newValue.intValue()* parallaxY/100);
                           //Вычисляем стартовую точку отрисовки прямоугольника - контура окна secondSample

                        //startPointYNew = (int) (newValue.intValue()*((maxContourY - paneSampleYReal) /(scalePaneSample*scale))/100);
                           //Вычисляем стартовую точку отрисовки прямоугольника - контура окна secondSample


                         // Передаем параметр слайдера в начальное смещение контура помещения по Y во втором окне secondSample

                         //startPointYSecWin = (int) (newValue.intValue()*(maxContourY - secondWindowYReal/(scalePaneSample*scale))/100);

                        float parallaxY2 = ( maxContourY * scale) - secondWindowYReal;
                           // 1.1F - Коэффициент увеличения смещения пряиоугольника окна secondWindow в PaneSample
                        if (parallaxY2 < 0) parallaxY2 = 0;

                        startPointYSecWin = (int) (newValue.intValue() * parallaxY2/100);

                        //StartPointElementsCollection startPointElementsCollection = StartPointElementsCollection.getInstance();
                        startPointElementsCollection.setStartPointElementsCollectionY( -startPointYSecWin);

                        saveParamGrid();
                         // Передаем параметры сетки в класс, их сохраняющий

                         // Перерисовываем второе окно SecondWindow

                        SecondWindow secondWindow = new SecondWindow();
                        try {
                            secondWindow.getSecondWindow(SecondWindowController.SecondWindowParam.DELETE,
                                    paramGrid,
                                    elementsCollection,
                                    StartPointElementsCollection.getInstance());

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

//
//
                    }
                });
            }

            //TimeUnit.SECONDS.toMillis(500);
            // sRS=0;  !!! - не обнулять - !!!

        }



        clearPaneSample();
            //стираем главную панель

        paneSampleMethodElemCollec(elementsCollection);
            // Отрисовываем контур помещения на главной панели

        RectangleDraw rectangleDraw = new RectangleDraw(scalePaneSample, startPointYNew);
        rectangleDraw.setStartPointY(startPointYNew);
        startPointYprom = startPointYNew;
        rectangleDraw.draw();
           // Отрисовываем прямоугольник окна secondSample в панели paneSample

           // Перерисовываем второе окно secondWindow
    }}

           // Метод стирания панели главного oкна

    public void clearPaneSample(){

               // Размеры окна - X - 738, Y - 540

        int j;

        for ( j = 0; j < 540; j = j + 10) {

            Line lineDelite = new Line();

            lineDelite.setStartX(0);
            lineDelite.setStartY(j);
            lineDelite.setEndX(738);
            lineDelite.setEndY(j);
            lineDelite.setStrokeWidth(10);
            lineDelite.setStroke(Color.SKYBLUE);
            paneSample.getChildren().add(lineDelite);
        }
    }

        // Метод отрисовки контура помещения

    public void paneSampleMethodElemCollec(ElementsCollection elementsCollection) {

          System.out. println("\n\n     paneSampleMethodElemCollec");

        // Углы u1*P рад u1*3.14
        float u1 = 0;
        float u2 = 0;
        float u3 = 0;

        // Длины предыдущего и последующего сегментов
        int dim1;
        int dim2;

        // абсолютные координаты текущей и следующей точек - Начинаем с 0!       int x0 = 10;        int y0 = 10;

        int x0 = 0;
        int y0 = 0;

        int x1;
        int y1;

        float PI = (float)Math.PI;;

        for (int i = 0; i < elementsCollection.size(); i++) {

            if (i==0) {

                dim1 = (int) ((elementsCollection.get(i).getLength())/scalePaneSample);

                x1 =  x0 + dim1;
                y1 =  y0;

                LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 2, Color.GREEN);
                lineDraw.lineDraw();

                u2 = elementsCollection.get(i).getAngle();
                u1 = 1 - u2;

                x0 = x1;
                y0 = y1;

            }else {

                dim1 = (int) ((elementsCollection.get(i).getLength())/scalePaneSample);


                x1 = (int) (x0 + dim1 * (Math.cos(PI*u1)));
                y1 = (int) (y0 + dim1 * (Math.sin(PI*u1)));

                LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 2, Color.GREEN);
                lineDraw.lineDraw();

                u2 = elementsCollection.get(i).getAngle();

                u1 = u1 - u2 - 3 / 2;



                x0 = x1;
                y0 = y1;
            }
        }
    }

//    public void sliderRightZeroAction(Event event) {
//
//
//    }
//
//    public void sliderLowerZeroAction(Event event) {
//
//
//
//    }

    public void itemSaveAction(ActionEvent actionEvent) throws IOException {

        System.out.println("\n   FileSaveWindow ");

              // Выбор директории для записи

            DirectoryChooser directoryChooser = new DirectoryChooser();

            directoryChooser.setTitle("coverdesigner Directory Selection");
            directoryChooser.setInitialDirectory(new File(System.getProperty("user.home")));
             File file = directoryChooser.showDialog(Main.primaryStage);

            System.out.println("Выбор папки " + file);
            // file - имя выбранной папки

        if (file != null) {

            TextInputDialog dialog = new TextInputDialog("example010");
            dialog.setTitle("coverdesigner");
            dialog.setHeaderText("Please enter file name");
            dialog.setContentText("  File Name:");

               // Traditional way to get the response value.
            Optional<String> result = dialog.showAndWait();




                if (result.isPresent()) {
                    if (result.get() != "  " & result.get() != null) {

                        System.out.println("File name:" + result.get() + "\n");


                        // string.toCharArray()

                        // Строка для сканирования, чтобы найти шаблон
                        String str = result.get();
                        String pattern = "\\W";

                        // Создание Pattern объекта
                        Pattern r = Pattern.compile(pattern);

                        // Создание matcher объекта
                        Matcher m = r.matcher(str);

                        if (m.find()) {

                            // Проверка на недопустимый символ

                            System.out.println("Не допустимый символ: " + m.group());

                            Alert alert = new Alert(Alert.AlertType.WARNING);
                            alert.setTitle("coverdesigner");
                            alert.setHeaderText("Invalid character in the name: " + m.group());
                            alert.setContentText(" Please try again!");

                            alert.showAndWait();


                        } else {

                            // Дополнительная проверка на присуствие букв и - или цифр

                            pattern = "\\w";

                            r = Pattern.compile(pattern);
                            m = r.matcher(result.get());

                            if (m.find()) {

                                String fileSave = file + File.separator + result.get() + ".cvd";

                                System.out.println("\n     Имя валидно: " + result.get());
                                  System.out.println("Адрес для записи: " + fileSave);

                                System.out.println("\nСохранение по адресу: " + fileSave);

                                // ElementsCollection elementsCollection = ElementsCollection.getInstance();


//                                // Сериализация
//
//                                  FileOutputStream fos = new FileOutputStream(fileSave);
//                                  ObjectOutputStream oos = new ObjectOutputStream(fos);
//
//                                  oos.writeObject(elementsCollection);
//
//                                  oos.close();
//                                  fos.close();


                                // Создание текстового файла для записи

                                  String text = "";
                                Integer length = 0;
                                Float    angle = 0F;

                                for (int i = 0; i < elementsCollection.size(); i++) {

                                     length = elementsCollection.get(i).getLength();
                                     angle  = elementsCollection.get(i).getAngle();

                                     text = text + length.toString() + "_" + angle.toString()+ "\n"  ;


                                }
                                System.out.println(text);


                                try(FileWriter fileWriter = new FileWriter(fileSave))
                                {
                                    // запись всей строки
                                    fileWriter.write(text);
                                }
                                catch(IOException ex){

                                    System.out.println(ex.getMessage());
                                }





                            } else {

                                System.out.println("\nПользователь ввел пустое имя: " + result.get());

                            }

                        }


                    }
                }


        }



    }

    public void itemOpenAction(ActionEvent actionEvent) throws IOException {

        System.out.println("\n   FileDowenloadWindow ");


        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("coverdesigner fileChooser");
        FileChooser.ExtensionFilter extFilter =
                new FileChooser.ExtensionFilter(" File (*.cvd)", "*.cvd");
        // Расширение
        fileChooser.getExtensionFilters().add(extFilter);

        fileChooser.setInitialFileName(("example010.cvd"));
        // Не работает

        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

        File file = fileChooser.showOpenDialog(Main.primaryStage);
        // Указываем текущую сцену Stage и получаем имя выбранного файла file

        System.out.println("Процесс открытия файла по адресу: " + file);
        // file - имя выбранного файла

        //int a = 0;
        System.out.println("\n Файл elementsCollection до перезагрузки: \n" + elementsCollection);

//        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
//        try {
//            elementsCollection = (ElementsCollection)ois.readObject();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }

        elementsCollection.clear();

        String line;
        int num = 0;
        float angl = 0F;
        String[] grup;
        int n = 0;

        if (file != null) {

            try {
                // File file = new File("/Users/prologistic/file.txt");
                //создаем объект FileReader для объекта File уже есть
                FileReader fr = new FileReader(file);
                //создаем BufferedReader с существующего FileReader для построчного считывания
                BufferedReader reader = new BufferedReader(fr);
                // считаем сначала первую строку
                line = reader.readLine();
                line = line.trim();
                n = 0;

                System.out.println("\n Считанный файл line: \n n = " + n +":\n" + line);


                while (line != null) {

                    System.out.println("\n Линия перед резкой = " + line);
                    grup = line.split("_");

                    num = Integer.parseInt(grup[0]);
                    angl = Float.parseFloat(grup[1]);

                    element.setLength(num);
                    element.setAngle(angl);

                    System.out.println("\n  длинна = " + num);
                    System.out.println("    угол = " + angl);

                    elementsCollection.add(n, element);

                    element = new Element();
                       // без этого обнуления работает некорректно!
                       // предыдущие element в коллекции elementCollection
                       // перезаписывает в текущем значении!!! - не понятно почему.

                    System.out.println("\n Файл elementsCollection при загрузке: \n" + n +":\n" + elementsCollection);

                    n++;
                    // считываем остальные строки в цикле
                    line = reader.readLine();
                }

                System.out.println("\n Файл elementsCollection после загрузки: \n" + elementsCollection);


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
            System.out.println("\n\nФайл elementsCollection после перезагрузки: \n" + elementsCollection);

          // Отрисовываем Второе окно и главное окно -

          buttonDrawAction(actionEvent);






    }

    public void itemCloseAction(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("coverdesigner");
        alert.setHeaderText("Confirm exit from the program coverdesigner");
        alert.setContentText("OK - exit the program, \nCANCEL - continue work");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            // ... user chose OK
            // Закрываем программу!!
            System.exit(0);

        } else {
            // ... user chose CANCEL or closed the dialog
        }




    }

    class LineDraw implements LineEdit {

        private int startX = 0;
        private int startY = 0;
        private int endX = 738;
        private int endY = 540;
        private int strokeWidth = 2;
        private Color stroke = Color.BLUE;

        public int getStartX() {
            return startX;
        }

        public int getStartY() {
            return startY;
        }

        public int getEndX() {
            return endX;
        }

        public int getEndY() {
            return endY;
        }

        public int getStrokeWidth() {
            return strokeWidth;
        }

        public Color getStroke() {
            return stroke;
        }

        public void setStartX(int startX) {
            this.startX = startX;
        }

        public void setStartY(int startY) {
            this.startY = startY;
        }

        public void setEndX(int endX) {
            this.endX = endX;
        }

        public void setEndY(int endY) {
            this.endY = endY;
        }

        public void setStrokeWidth(int strokeWidth) {
            this.strokeWidth = strokeWidth;
        }

        public void setStroke(Color stroke) {
            this.stroke = stroke;
        }

        public LineDraw(int startX, int startY, int endX, int endY, int strokeWidth, Color stroke) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
            this.strokeWidth = strokeWidth;
            this.stroke = stroke;
        }

        public LineDraw(int strokeWidth, Color stroke) {
            this.stroke = stroke;
            this.strokeWidth = strokeWidth;
        }

        public LineDraw(int startX, int startY, int endX, int endY) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
        }

        public void lineDraw() {
            Line lineStart = new Line();
            lineStart.setStartX(startX);
            lineStart.setStartY(startY);
            lineStart.setEndX(endX);
            lineStart.setEndY(endY);
            lineStart.setStrokeWidth(strokeWidth);
            lineStart.setStroke(stroke);
            paneSample.getChildren().add(lineStart);
        }
    }


    class RectangleDraw {

         public int startPointX = startPointXprom;
         public int startPointY = startPointYprom;
         float scalePaneSampleL = scalePaneSample;

        ElementsCollectionRectangle elementsCollectionRectangle =  ElementsCollectionRectangle.getInstance();


        public RectangleDraw() {}

        public RectangleDraw(int startPointX, int startPointY) {
            this.startPointX = startPointX;
            this.startPointY = startPointY;
        }

        public RectangleDraw(int startPointX, int startPointY, float scalePaneSampleL) {
            this.startPointX = startPointX;
            this.startPointY = startPointY;
            this.scalePaneSampleL = scalePaneSampleL;
        }

        public RectangleDraw(int startPointX, float scalePaneSampleL) {
            this.startPointX = startPointX;
            this.scalePaneSampleL = scalePaneSampleL;
        }

        public RectangleDraw(float scalePaneSampleL, int startPointY) {
            this.startPointY = startPointY;
            this.scalePaneSampleL = scalePaneSampleL;
        }

        public int getStartPointX() {
            return startPointX;
        }

        public void setStartPointX(int startPointX) {
            this.startPointX = startPointX;
        }

        public int getStartPointY() {
            return startPointY;
        }

        public void setStartPointY(int startPointY) {
            this.startPointY = startPointY;
        }

        public float getScalePaneSampleL() {
            return scalePaneSampleL;
        }

        public void setScalePaneSampleL(float scalePaneSampleL) {
            this.scalePaneSampleL = scalePaneSampleL;
        }

        protected void draw(){

            System.out. println("\n\n   RectangleDraw.draw ");
            System.out. println("    scalePaneSampleL = " + scalePaneSampleL);
            System.out. println("    scalePaneSample = " + scalePaneSample);

            // Углы u1*P рад u1*3.14
            float u1 = 0;
            float u2 = 0;
            float u3 = 0;

            // Длины предыдущего и последующего сегментов
            int dim1;
            int dim2;

            // абсолютные координаты текущей и следующей точек
            int x0 =  startPointX;
            int y0 =  startPointY;

              System.out. println("\n\n   RectangleDraw.draw startPointX = " + startPointX);
              System.out. println("   RectangleDraw.draw startPointY = " + startPointY);

            int x1;
            int y1;

            float PI = (float)Math.PI;

            if ((x0 + (int) (secondWindowXReal/(scalePaneSampleL*scale))> paneSampleXReal)){

                x0 = paneSampleXReal -(int) (secondWindowXReal/(scalePaneSampleL*scale));
                if (x0 < 0){x0 = 0;}
            }

            if (y0 + (int) (secondWindowYReal/(scalePaneSampleL*scale))  > paneSampleYReal){
                y0 = paneSampleYReal - (int) (secondWindowYReal/(scalePaneSampleL*scale)) ;
                if (y0 < 0){y0 = 0;}
            }



            for (int i = 0; i < elementsCollectionRectangle.size(); i++) {

                if (i==0) {

                      System.out. println("\n   RectangleDraw.draw i = " + i);

                    dim1 = (int) ((elementsCollectionRectangle.get(i).getLength())/(scalePaneSampleL*scale));
                      System.out. println("   RectangleDraw.draw dim1 = " + dim1);

                    x1 =  x0 + dim1;
                      System.out. println("   RectangleDraw.draw x1 = " + x1);

                    y1 =  y0;
                      System.out. println("   RectangleDraw.draw y1 = " + y1);





                      if (x1 > paneSampleXReal){
                          x1 = paneSampleXReal;
                      }

                    if (y1 > paneSampleYReal){
                        y1 = paneSampleYReal;
                    }


                    LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 2, Color.CYAN);
                    lineDraw.lineDraw();

                    u2 = elementsCollectionRectangle.get(i).getAngle();

                    u1 = 1 - u2;

                    x0 = x1;
                    y0 = y1;



                }else {

                      System.out. println("\n   RectangleDraw.draw i = " + i);

                    dim1 = (int) ((elementsCollectionRectangle.get(i).getLength())/(scalePaneSampleL*scale));

                      System.out. println("     RectangleDraw.draw dim1 = " + dim1);

                    x1 = (int) (x0 + dim1 * (Math.cos(PI*u1)));
                    y1 = (int) (y0 + dim1 * (Math.sin(PI*u1)));

                      System.out. println("    RectangleDraw.draw x1 = " + x1);
                      System.out. println("    RectangleDraw.draw y1 = " + y1);

                    if (x1 > paneSample.getWidth()){ x1 = (int)paneSample.getWidth();}
                    if (y1 > paneSample.getHeight()){ y1 = (int)paneSample.getHeight();}

                    LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 2, Color.CYAN);
                    lineDraw.lineDraw();

                    u2 = elementsCollectionRectangle.get(i).getAngle();

                    u1 = u1 - u2 - 3 / 2;

                    x0 = x1;
                    y0 = y1;
                }
            }

            ContourCleaning contourCleaning = new ContourCleaning ();
            contourCleaning.clean();
        }

        protected class ContourCleaning  {

            int x10,y10,x11,y11;


          protected void clean  () {

              // очистка верхнего контура

              x10 = -100;
              y10 = -105;
              x11 = paneSampleXReal -95;
              y11 = -105;


              LineDraw lineDraw01 = new LineDraw(x10, y10, x11, y11, 200, Color.rgb(244,244,244));
              lineDraw01.lineDraw();

               // Очистка левого контура

              x10 = -105;
              y10 = -100;
              x11 = -105;
              y11 = paneSampleYReal + 600;

              LineDraw lineDraw02 = new LineDraw(x10, y10, x11, y11, 200, Color.rgb(244,244,244));
              lineDraw02.lineDraw();

                // очистка нижнего контура

              x10 = paneSampleXReal - 400;
              y10 = 940;
              x11 = paneSampleXReal - 400;
              y11 = 1230;

              LineDraw lineDraw03 = new LineDraw(x10, y10, x11, y11, 808, Color.rgb(244,244,244));
              lineDraw03.lineDraw();

                // Очистка правого контура - блокирует правые слайдеры

//              x10 = paneSampleXReal + 200;
//              y10 = -100;
//              x11 = paneSampleXReal + 200;
//              y11 = paneSampleYReal + 400;
//
//              LineDraw lineDraw04 = new LineDraw(x10, y10, x11, y11, 400, Color.GREEN);
//              lineDraw04.lineDraw();



            }

        }


      }
    }


