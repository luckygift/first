package com.yuri;

import java.io.*;

public class DataSave implements Serializable {


    private int tileWidthC = 100;

    private int tileHeightC = 300;

    private int tileSeamC = 10;

    private int biasXC = 7;

    private int biasYC = 5;

    private float scaleC = 1.0F;

    private double angleRotationC = 0;

    int maxContourXC = 0;
    int maxContourYC = 0;
    float scalePaneSampleC = 1;

    public int startPointXNewC = 0;
    public int startPointYNewC = 0;

    public int startPointXpromC = 0;
    public int startPointYpromC = 0;

    public int startPointXSecWinC= 0;
    public int startPointYSecWinC = 0;

     private static ElementsCollection elementsCollection = ElementsCollection.getInstance();

   // private  ElementsCollection elementsCollection;


    public DataSave() {}

    public DataSave(ElementsCollection elementsCollection) {
        this.elementsCollection = elementsCollection;
    }

    protected void fieldRead() {



    }

    protected static void fieldWrite(String string) {


        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(string);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(fos);
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
             oos.writeObject(elementsCollection);




        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            oos.close();
       } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            fos.close();
        } catch (IOException e) {
           e.printStackTrace();
        }

        System.out.println("Вызов fieldWrite: " + string);


    }
}
