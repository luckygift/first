package com.yuri;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DialogController {

    private ResourceBundle resourceBundle;

    @FXML
    public TextField tfLength;

      protected String tfLengthString;

    @FXML
    public TextField tfAngle;

      protected String tfAngleString;

    @FXML
    private Label labelCount;

    public int contourNamb = 0;

    Element element = new Element() ;


    @FXML
    private Label labelLength;

    @FXML
    private Label labelAngle;

    ElementsCollection elementsCollection = ElementsCollection.getInstance();

       // Переменные проверки валидноси

    private String pattern;
    private Pattern r;
    private Matcher m;

    private WindowErrorNumberFormat windowErrorNumberFormat = new WindowErrorNumberFormat();

//    @FXML
    public void initialize () {
        labelCount.setText("  Entering contour elements " + ++contourNamb);
    }

    public void tfLengthAction(ActionEvent actionEvent) {
        tfLengthString = tfLength.getText();

        // Проверка ввода числового формата

        pattern = "\\D";
        r = Pattern.compile(pattern);
        m = r.matcher(tfLengthString);

        if (m.find()) {

            // Формат не верный

               System.out.println("Не верный формат ввода числа");

            windowErrorNumberFormat.show();

        } else {

            pattern = "\\d";
            r = Pattern.compile(pattern);
            m = r.matcher(tfLengthString);

                if (m.find()) {

                    // Формат верный

                       System.out.println("\n Формат поля tfLengthString правельный: " + tfLengthString);

                    if (checkInt(tfLengthString)) {
                        element.setLength(Integer.parseInt(tfLengthString));
                        labelLength.setText("ok");
                        //element.setLength(Integer.parseInt(tfLengthString));

                    } else {

                        // Не верный диапазон числа
                        labelLength.setText("repeat");

                    }
                }
            }
        }




    public void tfAngleAction(ActionEvent actionEvent) {
        tfAngleString = tfAngle.getText();

        // Проверка ввода формата float

        pattern = "[A-Za-zА-Яа-я]";
        r = Pattern.compile(pattern);
        m = r.matcher(tfAngleString);

        if (!m.find()) {

            pattern = "^[0-2](\\u002E\\d+)?$";
            r = Pattern.compile(pattern);
            m = r.matcher(tfAngleString);

            if (m.find()) {

                    // Формат верный

                    System.out.println("\n Формат поля tfAnglString правельный: " + tfAngleString);

                    if (checkFloat(tfAngleString)) {
                        element.setAngle(Float.parseFloat(tfAngleString));
                        labelAngle.setText("ok");
                        //element.setAngle(Float.parseFloat(tfAngleString));
                    } else labelAngle.setText("repeat");


                } else {

                    System.out.println(" 1 Не верный формат ввода числа");
                    windowErrorNumberFormat.show();



            }

        }else{

        // Формат не верный

               System.out.println(" 00 Не верный формат ввода числа");


            windowErrorNumberFormat.show();

    }
  }



    public void buttonNextAction(ActionEvent actionEvent) {

        if ( labelLength.getText() == "ok" && labelAngle.getText()=="ok" ) {

            //contourNamb ++;

              // ElementsCollection elementsCollection = ElementsCollection.getInstance();
            if (contourNamb-1 == 0) {
                elementsCollection.clear();
            }
            elementsCollection.add(contourNamb-1, element);

              System.out.println(element.getLength());
              System.out.println(element.getAngle());

            element = new Element();

              System.out.println(element.getLength());
              System.out.println(element.getAngle());

            labelCount.setText("  Entering contour elements " + ++contourNamb);


              System.out.println(elementsCollection);

            elCollectionToString();

            labelLength.setText("10...10000");
            labelAngle.setText("0...2.0");

            tfLength.setText("");
            tfAngle.setText("");
        }


    }

    public void buttonLastAction(ActionEvent actionEvent) {

        if ( labelLength.getText() == "ok"
                //&& labelAngle.getText()=="ok"
                ) {
            //contourNamb ++;

            element.setAngle(0);
            //Последний угол не учитывается

               //ElementsCollection elementsCollection = ElementsCollection.getInstance();
            elementsCollection.add(contourNamb-1, element);
            element = new Element();

              System.out.println(element.getLength());
              System.out.println(element.getAngle());

            // Обнуление параметров

            contourNamb = 0;

            tfLength.setText("");
            tfAngle.setText("");

            labelLength.setText("repeat");
            labelAngle.setText("repeat");

            labelCount.setText("  Entering contour elements " + ++contourNamb);

              System.out.println(elementsCollection);

              elCollectionToString();
        }

    }


    public void buttonResetAction(ActionEvent actionEvent) {
        contourNamb = 0;
        labelCount.setText("  Entering contour elements " + ++contourNamb);
        //ElementsCollection elementsCollection = ElementsCollection.getInstance();
        elementsCollection.clear();

        tfLength.setText("");
        tfAngle.setText("");

        labelLength.setText("repeat");
        labelAngle.setText("repeat");

          System.out.println( elementsCollection);

          elCollectionToString();

    }

    private boolean checkInt(String string) {
        if (!(string.trim().length() ==0) &&
                (10<Integer.parseInt(string)) &&
                (Integer.parseInt(string)<10000)) {
            return true;
        }else {
            return false;
        }

    };

    private boolean checkFloat(String string) {
        if (!(string.trim().length() == 0) &&
                (0 <= Float.parseFloat(string)) &&

                (Float.parseFloat(string) <= 2)) {

            return true;

        } else {
            return false;
        }
    }

    private String elCollectionToString(){
        //ElementsCollection elementsCollection = ElementsCollection.getInstance();
        String elements = "";
        int i = 0;
        for ( i = 0; i < elementsCollection.size(); ++i) {
            elements ="\n\n  " +
            elements +"\n\n  " +
           "Length " + i +" = " + elementsCollection.get(i).getLength() +
                    "\n  Angle  " + i + " = " + elementsCollection.get(i).getAngle() + "\n";}

             System.out.println(elements);


        return elements;
    }
}
