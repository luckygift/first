package com.yuri;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public  final class DialogWindow {

    private static DialogWindow instance = null;

    static Pane loadD;
    static Stage dialogStage;



    private    DialogWindow () throws IOException {
        FXMLLoader loaderDialog = new FXMLLoader(getClass().getResource("/Dialog.fxml"));
        loadD =  loaderDialog.load();
        dialogStage = new Stage();
        dialogStage.setTitle("Dialog");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        // dialogStage.initOwner(((Node)actionEvent.getSource()).getScene().getWindow());

        dialogStage.initOwner(Main.primaryStage);
        Scene sceneD = new Scene(loadD);
        dialogStage.setScene(sceneD);
        dialogStage.show();
    }

    public  static DialogWindow  getInstance() throws IOException {
        if (instance == null) return instance = new DialogWindow();

        dialogStage.show();


        return instance;
    }
}
