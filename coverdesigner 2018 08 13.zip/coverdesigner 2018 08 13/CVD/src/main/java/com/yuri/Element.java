package com.yuri;

import java.io.Serializable;

public class Element implements Serializable {
   private int length = 0;
   private float angle = 0F;

    public Element() { }

    public Element(int length, float angle) {
        this.length = length;
        this.angle = angle;
    }

    public Element(int length) {
        this.length = length;
    }

    public Element(float angle) {
        this.angle = angle;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public float getAngle() {
        return angle;
    }

    public void setAngle(float angle) {
        this.angle = angle;
    }

    @Override
    public String toString() {
        return "Element \n" + "Length = " + length + "\n" +
                "Angle = " + angle + "\n" ;
    }
}
