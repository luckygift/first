package com.yuri;

import java.io.Serializable;
import java.util.ArrayList;

public final class ElementsCollection extends ArrayList<Element> implements Serializable {

    protected static ElementsCollection instance = null;

    private ElementsCollection() {}

    public static ElementsCollection getInstance() {
        if (instance == null) {
            instance = new ElementsCollection();
        }

        return instance;

    }
}





