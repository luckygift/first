package com.yuri;

import java.util.ArrayList;

public final class ElementsCollectionRectangle extends ArrayList<Element> {



        public static ElementsCollectionRectangle instance = null;

        private ElementsCollectionRectangle() {}


        public static ElementsCollectionRectangle getInstance() {


            if (instance == null) {

                instance = new ElementsCollectionRectangle();

                Element element = new Element(1216, 0.5f);

                 instance.add(0, element);
                element = new Element(889, 0.5f);
                 instance.add(1, element);
                element = new Element(1216, 0.5f);
                 instance.add(2, element);
                element = new Element(889, 0.5f);
                 instance.add(3, element);

            }

            return instance;

        }
    }


