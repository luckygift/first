package com.yuri;

import java.util.ArrayList;

public class ElementsCollectionSave extends ArrayList<Element> {

    public ElementsCollectionSave() {
    }

    protected static ElementsCollectionSave instance = null;



    public static ElementsCollectionSave getInstance() {
        if (instance == null) {
            instance = new ElementsCollectionSave();
        }

        return instance;

    }


}
