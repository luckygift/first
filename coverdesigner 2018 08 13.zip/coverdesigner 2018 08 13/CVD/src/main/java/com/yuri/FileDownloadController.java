package com.yuri;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class FileDownloadController {

    @FXML
    protected TextField tfnDownload;


    public void butonDownloadAction(ActionEvent actionEvent) {

    }

    public void butonCancelAction(ActionEvent actionEvent) throws IOException {

        FileDownloadWindow fileDownloadWindow = FileDownloadWindow.getInstance();
        fileDownloadWindow.dialogStage.close();

    }
}
