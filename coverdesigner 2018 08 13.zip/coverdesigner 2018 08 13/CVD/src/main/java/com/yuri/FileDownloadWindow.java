package com.yuri;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class FileDownloadWindow {

    private static FileDownloadWindow instance = null;

    static Pane loadD;
    static Stage dialogStage;



    private    FileDownloadWindow () throws IOException {

        FXMLLoader fileDownloadLoader = new FXMLLoader(getClass().getResource("FileDownload.fxml"));
        loadD =  fileDownloadLoader.load();
        dialogStage = new Stage();
        dialogStage.setTitle("Download");
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        // Модальное окно

        //dialogStage.initModality(Modality.WINDOW_MODAL);
        // dialogStage.initOwner(((Node)actionEvent.getSource()).getScene().getWindow());

        dialogStage.initOwner(Main.primaryStage);
        Scene sceneD = new Scene(loadD);
        dialogStage.setScene(sceneD);
        dialogStage.show();
    }

    public  static FileDownloadWindow  getInstance() throws IOException {

        if (instance == null) return instance = new FileDownloadWindow();

        dialogStage.show();


        return instance;
    }

}
