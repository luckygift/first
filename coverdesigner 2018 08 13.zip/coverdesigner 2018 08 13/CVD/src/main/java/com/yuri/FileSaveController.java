package com.yuri;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;

public class FileSaveController {

    @FXML
    protected TextField tfnSave;
    

    public void butonSaveAction(ActionEvent actionEvent) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        FileChooser.ExtensionFilter extFilter =
                new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
                  //Расширение
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showOpenDialog(FileSaveWindow.dialogStage);
                 //Указываем текущую сцену Stage

                System.out.println("Процесс открытия файла " + file);
                   // file - имя выбранного файла

    }

    public void butonCancelAction(ActionEvent actionEvent) throws IOException {

        FileSaveWindow fileSaveWindow = FileSaveWindow.getInstance();
        fileSaveWindow.dialogStage.close();
    }
}
