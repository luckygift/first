package com.yuri;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class FileSaveWindow {
    private static FileSaveWindow instance = null;

    static Pane loadD;
    static Stage dialogStage;



    private    FileSaveWindow () throws IOException {
        FXMLLoader fileSaveLoader = new FXMLLoader(getClass().getResource("FileSave.fxml"));
        loadD =  fileSaveLoader.load();
        dialogStage = new Stage();
        dialogStage.setTitle("Save");
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        //dialogStage.initModality(Modality.WINDOW_MODAL);

        // dialogStage.initOwner(((Node)actionEvent.getSource()).getScene().getWindow());

        // dialogStage.initOwner( Main());

       // dialogStage.initOwner( Main.primaryStage) ;
        dialogStage.initOwner(Main.primaryStage);
        Scene sceneD = new Scene(loadD);
        dialogStage.setScene(sceneD);
        dialogStage.show();
    }

    public  static FileSaveWindow  getInstance() throws IOException {
        if (instance == null) return instance = new FileSaveWindow();

        dialogStage.show();


        return instance;
    }


}
