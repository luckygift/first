package com.yuri;

/**
 * Created by Papa on 20.04.2017.
 */
public interface LineEdit {
    //tileWidth - ширина плитки-мм
   // int tileWidth=50;
    //tileHeight - высота плитки-мм
   // int tileHeight=50;
    // jointWidth - ширина шва-мм
    int jointWidth=5;
    // biasX смещение по Х-мм
    int biasX=0;
    // biasY смещение по Y-мм
    int biasY=0;
    // scale - масштаб
    double scale=1;
    //angleRotation - угол поворота-рад
    double angleRotation =0;
    //windowWidth - ширина окна X- рх
    int windowWidth=800;
    //windowHeight - высота окна Y- рх
    int windowHeight=800;
}
