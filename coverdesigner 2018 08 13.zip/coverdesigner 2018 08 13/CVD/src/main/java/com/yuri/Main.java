package com.yuri;
/* coverdsugner - автор Кравчик Юрий Сулевич. Все права сохранены. 2018г.
   Программа предназначена для моделирования раскладки прямоугольной плитки на плоской поверхности,
   ограниченной отрезками прямых.

   При укладке плитки существует техническая сложность при уклладке на маленькие участки поверхности.
   Маленькие куски плитки сложно отрезать и сформировать под нужными углами.
   Это создает и эстетический диссонанс.
   Один из вариантов решения - моделирование раскладки плитки для устранения "малых" размеров
   отрезания из раскладки.
   Программа позволяет задать место начала укладки плитки.

   Программа позволяет:
    ввести котур помещения отрезками прямых линий.
    Задать угол между отрезками.
    Задать размеры плитки.
    задать расстояние между плитками.
    Задать угол раскладки плитки.
    Моделировать размещение плитки относительно контура помещения.
    Смещать раскладку плитки относительно контура помещения.
    Сохранить контур помещения.
    Открыть сохраненный контур помещения.
    Посмотреть раскладку плитки вдоль контура помещения.
    Задать масштаб изображения.

 */





import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application {

   public static Pane load;
   public static Stage mystage;
   public static FXMLLoader loader;
   public static Stage primaryStage;

    @Override
    public void start(final Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/sample.fxml"));
        primaryStage.setTitle("coverdesigner");

        primaryStage.setMinHeight(600);
        primaryStage.setMinWidth(600);
        primaryStage.setResizable(false);
        primaryStage.setHeight(705.0);
        primaryStage.setWidth(860.0);

        Scene scene = new Scene (root,850,850);
          scene.getStylesheets().add(0,"/my.css");
        primaryStage.setScene(scene);

        // Устанавливаем фиксированный размер фрейма-иначе трудно подбирать размер окна при стирании и перерисовке.
       // primaryStage.setFullScreen(true);

       // primaryStage.initModality(APPLICATION_MODAL);
                primaryStage.show();

         // Предустановка окна SecondSample:

        loader = new FXMLLoader(getClass().getResource("/SecondSample.fxml"));

        load =  loader.load();
        mystage = new Stage();
        mystage.setTitle("SecondSample");


//        mystage.setWidth(1226.0);
//        mystage.setHeight(899.0);

        mystage.setWidth(1216.0);
        mystage.setHeight(889.0);
        mystage.setResizable(false);
          // - фиксирует размер окна

        Scene scene2 = new Scene(load);
        mystage.setScene(scene2);

    }


    public static void main(String[] args) {
        launch(args);
    }

}
