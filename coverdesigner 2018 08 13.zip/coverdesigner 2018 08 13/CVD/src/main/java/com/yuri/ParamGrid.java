package com.yuri;

public class ParamGrid {

    //tileWidth - ширина плитки-мм
    private int tileWidth = 50;

    //tileHeight - высота плитки-мм
    private int tileHeight = 60;

    // tileSeam - ширина шва-мм
    private int tileSeam = 1;

    // biasX смещение по Х-мм
    private int biasX = 7;

    // biasY смещение по Y-мм
    private int biasY = 5;

    // scale - масштаб
    // 0.001 - 10
    private double scale = 0.5;

    //angleRotation - угол поворота-рад
    //0<angleRotation <=1.57 !!- угол поворота-рад
    private double angleRotation = 0.1;


    public ParamGrid() {}

    public static ParamGrid instance = null;

    public ParamGrid getInstance() {
        if (instance ==null){
            instance = new ParamGrid();
        }

        return instance;
    };

    public int getTileWidth() {
        return tileWidth;
    }

    public void setTileWidth(int tileWidth) {
        this.tileWidth = tileWidth;
    }


    public double getAngleRotation() {
        return angleRotation;
    }

    public void setAngleRotation(double angleRotation) {
        this.angleRotation = angleRotation;
    }


    public double getScale() {
        return scale;
    }

    public void setScale(double scale) {
        this.scale = scale;
    }


    public int getBiasY() {
        return biasY;
    }

    public void setBiasY(int biasY) {
        this.biasY = biasY;
    }


    public int getBiasX() {
        return biasX;
    }

    public void setBiasX(int biasX) {
        this.biasX = biasX;
    }


    public int getTileSeam() {
        return tileSeam;
    }

    public void setTileSeam(int tileSeam) {
        this.tileSeam = tileSeam;
    }


    public int getTileHeight() {
        return tileHeight;
    }

    public void setTileHeight(int tileHeight) {
        this.tileHeight = tileHeight;
    }
}
