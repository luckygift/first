package com.yuri;

import java.io.Serializable;

public class Saving implements Serializable {


}
