package com.yuri;

import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.io.IOException;

public class SecondWindow {
               // Отрисовка второго окна - сцены и его отображение

    Stage mystage = Main.mystage;
    FXMLLoader loader = Main.loader;


    public SecondWindow() {}

    public  void getSecondWindow(SecondWindowController.SecondWindowParam param,
                                 ParamGrid paramGrid,
                                 ElementsCollection elementsCollection,
                                 StartPointElementsCollection startPointElementsCollection)
                                 throws IOException {
                                   // Принимаемые параметы - окно SecondWindow,
                                   // параметры сетки - ParamGrid
                                   // параметры контура помещения - ElementsCollection
                                   // параметры начальной точки отрисовки контура помещения


        SecondWindowController secondWindowController =  loader.getController();
           //получаем контроллер для второй формы

        paramGrid.getInstance();
           // Получаем экземпляр с параметрами сетки

        startPointElementsCollection.getInstance();
           // Получаем экземпляр с параметрами начальной точки отрисовки контура помещения

           System.out.println("secondWindow " );
           System.out.println("SecondWindow.angleRotation     paramGrid " + paramGrid.getAngleRotation());


        secondWindowController.secondWindowMethod(param);
           // Стирание сцены -

        secondWindowController.secondWindowMethodGrid(paramGrid);
           // Отрисовываем сетку

        secondWindowController.secondWindowMethodElemCollec(elementsCollection);
          // Отрисовываем контур помещения на втором окне secondWindow

        secondWindowController.secondWindowMethodStartPointElementsCollection(startPointElementsCollection);
           // Передаем параметры начальной точки отрисовки контура помещения


           System.out.println("\n\n   SecondWindow show");

        mystage.show();
           // Отобразить сцену
    }
}
