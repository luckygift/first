package com.yuri;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class SecondWindowController {

    SecondWindowParam param;

    //tileWidth - ширина плитки-мм
    private int tileWidth = 100;

    //tileHeight - высота плитки-мм
    private int tileHeight = 300;

    // tileSeam - ширина шва-мм
    private int tileSeam = 10;

    // biasX смещение по Х-мм
    private int biasX = 7;

    // biasY смещение по Y-мм
  // static private int biasY = 5;

     private int biasY = 5;

    // scale - масштаб
    // 0.001 - 10
    private double scale = 1.0;

    //angleRotation - угол поворота-рад
    //0<angleRotation <=1.57 !!- угол поворота-рад
    private double angleRotation = 0;

    @FXML
    public Pane paneMain;

    // абсолютные координаты (начальной) текущей точки отрисовки контура помещения - и сетки
    protected int x0 = 0;
    protected int y0 = 0;

    // абсолютные координаты (начальной) текущей точки отрисовки сетки
    protected int X0 = 0;
    protected int Y0 = 0;




    public SecondWindowController instance = null;

    public SecondWindowController getInstance() {
        if (instance ==null){
            instance = new SecondWindowController();
        }

        return instance;
    };

    public void secondWindowMethod(SecondWindowParam param) {
        switch (param) {
            case DELETE:
                // Очищаем paneMain:


                System.out.println("Метод контроллера - пишем");
                System.out.println("Ширина paneMain - " + paneMain.getWidth());
                System.out.println("Высота paneMain - " + paneMain.getHeight());

                CleanPane cleanPane = new CleanPane();
                cleanPane.deliteOll();


                System.out.println("Ширина paneMain - 2 - " + paneMain.getWidth());
                System.out.println("Высота paneMain - 2 - " + paneMain.getHeight());


                break;

            case GRIDDRAW7:

                break;

            case GRIDDRAW4:

                break;

            case GRIDDRAW3:

                break;

            case GRIDDRAW2:

                break;

            case GRIDDRAW1:

                break;

            case GRIDPSETBIASY  :

                break;
        }

    }


    public void secondWindowMethodGrid(ParamGrid paramGrid) {

        //tileWidth - ширина плитки-мм
        this.tileWidth = paramGrid.getTileWidth();

        //tileHeight - высота плитки-мм
        this.tileHeight = paramGrid.getTileHeight();

        // tileSeam - ширина шва-мм
        this.tileSeam = paramGrid.getTileSeam();

        // biasX смещение по Х-мм
        this.biasX = paramGrid.getBiasX();

        // biasY смещение по Y-мм
        this.biasY = paramGrid.getBiasY();

        // scale - масштаб
        // 0.001 - 10
        this.scale = paramGrid.getScale();

        //angleRotation - угол поворота-рад
        //0<angleRotation <=1.57 !!- угол поворота-рад
        this.angleRotation = paramGrid.getAngleRotation();

        System.out.println("angleRotation " + angleRotation);

        System.out.println("paramGrid");

        GridP gridP = new GridP(tileWidth, tileHeight, tileSeam, scale, angleRotation, biasY, biasX);
        gridP.makeGridDraw();



    }

    public void secondWindowMethodStartPointElementsCollection(StartPointElementsCollection startPointElementsCollection){

       startPointElementsCollection.getInstance();
           // Получаем экземпляр с параметрами начальной точки отрисовки контура помещения

       x0 = startPointElementsCollection.getStartPointElementsCollectionX();
       y0 = startPointElementsCollection.getStartPointElementsCollectionY();

       X0 = startPointElementsCollection.getStartPointElementsCollectionX();
       Y0 = startPointElementsCollection.getStartPointElementsCollectionY();

    }

            // метод отрисовки контура помещения

    public void secondWindowMethodElemCollec(ElementsCollection elementsCollection) {

             System.out. println("\n\n     secondWindowMethodElemCollec");

       // LineDraw lineDraw1 = new LineDraw(10, 10, 100, 200, 6, Color.RED);

              // Углы u1*PI рад u1*3.14
           float u1 = 0;
           float u2 = 0;
           float u3 = 0;

              // Длины предыдущего и последующего сегментов
           int dim1;
           int dim2;

              // абсолютные координаты (начальной) текущей точки отрисовки контура помещения
              // передаются отдельным методом
           // x0 = 0;
           // y0 = 0;

              // и следующей точки
           int x1;
           int y1;



           float PI = (float)Math.PI;;

        for (int i = 0; i < elementsCollection.size(); i++) {

            if (i==0) {

                dim1 = (int) (elementsCollection.get(i).getLength()*scale);


                x1 =  x0 + dim1;
                y1 =  y0;

                LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 4, Color.GREEN);
                lineDraw.lineDraw();

                u2 = elementsCollection.get(i).getAngle();

                u1 = 1 - u2;

                x0 = x1;
                y0 = y1;



            }else {

                dim1 = (elementsCollection.get(i).getLength());



                x1 = (int) (x0 + dim1 * (Math.cos(PI*u1) * scale));
                y1 = (int) (y0 + dim1 * (Math.sin(PI*u1) * scale));

                LineDraw lineDraw = new LineDraw(x0, y0, x1, y1, 4, Color.GREEN);
                lineDraw.lineDraw();

                u2 = elementsCollection.get(i).getAngle();

                u1 = u1 - u2 - 3 / 2;



                x0 = x1;
                y0 = y1;


            }
        }
    }




    public enum SecondWindowParam {
        DELETE,
        GRIDDRAW7  {
            //tileWidth - ширина плитки-мм
            private int tileWidth = 50;
            //tileHeight - высота плитки-мм
            private int tileHeight = 60;
            // tileSeam - ширина шва-мм
            private int tileSeam = 1;
            // biasX смещение по Х-мм
            private int biasX = 7;
            // biasY смещение по Y-мм
            private int biasY = 5;
            // scale - масштаб
            // 0.001 - 10
            private double scale = 0.5;
            //angleRotation - угол поворота-рад
            //0<angleRotation <=1.57 !!- угол поворота-рад
            private double angleRotation = 0.1;

        },

        GRIDDRAW4  {
            //tileWidth - ширина плитки-мм
            private int tileWidth = 50;
            //tileHeight - высота плитки-мм
            private int tileHeight = 60;
            // tileSeam - ширина шва-мм
            private int tileSeam = 1;
//            // biasX смещение по Х-мм
//            private int biasX = 7;
//            // biasY смещение по Y-мм
//            private int biasY = 5;
            // scale - масштаб
            // 0.001 - 10
            private double scale = 0.5;
//            //angleRotation - угол поворота-рад
//            //0<angleRotation <=1.57 !!- угол поворота-рад
//            private double angleRotation = 0.1;

        },

        GRIDDRAW3  {
            //tileWidth - ширина плитки-мм
            private int tileWidth = 50;
            //tileHeight - высота плитки-мм
            private int tileHeight = 60;
            // tileSeam - ширина шва-мм
            private int tileSeam = 1;
            // biasX смещение по Х-мм
//            private int biasX = 7;
//            // biasY смещение по Y-мм
//            private int biasY = 5;
//            // scale - масштаб
//            // 0.001 - 10
//            private double scale = 0.5;
//            //angleRotation - угол поворота-рад
//            //0<angleRotation <=1.57 !!- угол поворота-рад
//            private double angleRotation = 0.1;

        },

        GRIDDRAW2  {
//            //tileWidth - ширина плитки-мм
//            private int tileWidth = 50;
//            //tileHeight - высота плитки-мм
//            private int tileHeight = 60;
//            // tileSeam - ширина шва-мм
//            private int tileSeam = 1;
            // biasX смещение по Х-мм
            private int biasX = 7;
            // biasY смещение по Y-мм
            private int biasY = 5;
//            // scale - масштаб
//            // 0.001 - 10
//            private double scale = 0.5;
//            //angleRotation - угол поворота-рад
//            //0<angleRotation <=1.57 !!- угол поворота-рад
//            private double angleRotation = 0.1;

        },

        GRIDDRAW1  {
//            //tileWidth - ширина плитки-мм
//            private int tileWidth = 50;
//            //tileHeight - высота плитки-мм
//            private int tileHeight = 60;
//            // tileSeam - ширина шва-мм
//            private int tileSeam = 1;
//            // biasX смещение по Х-мм
//            private int biasX = 7;
//            // biasY смещение по Y-мм
//            private int biasY = 5;
//            // scale - масштаб
//            // 0.001 - 10
//            private double scale = 0.5;
            //angleRotation - угол поворота-рад
            //0<angleRotation <=1.57 !!- угол поворота-рад
            private double angleRotation = 0.1;

        },

         GRIDPSETBIASY {
            public double biasY01=0;

        };







    }

    public void delite() {
        CleanPane cleanPane = new CleanPane();
        cleanPane.deliteOll();

    }

    public class CleanPane {
        public void deliteOll() {


            Line lineDelite = new Line();
            lineDelite.setStartX(635);
            //lineDelite.setStartX((int) paneMain.getHeight()/1);

            // Подбираем поле стирания
            // lineDelite.setStartY((int)paneMain.getWidth()/100);
            lineDelite.setStartY(0);
            lineDelite.setEndX(635);
            lineDelite.setEndY(485);
            lineDelite.setStrokeWidth(1270);
            lineDelite.setStroke(Color.SKYBLUE);
            paneMain.getChildren().add(lineDelite);

        }

    }


    @FXML
    public void initialize () {}

    public class GridP //implements GridDraw
    {


        //tileWidth - ширина плитки-мм
        private int tileWidth = 50;

        //tileHeight - высота плитки-мм
        private int tileHeight = 60;

        // tileSeam - ширина шва-мм
        private int tileSeam = 1;

        // biasX смещение по Х-мм
        private int biasX = 7;

        // biasY смещение по Y-мм
        private int biasY = 5;

        // scale - масштаб
        // 0.001 - 10
        private double scale = 0.5;

        //angleRotation - угол поворота-рад
        //0<angleRotation <=1.57 !!- угол поворота-рад
        private double angleRotation = 0.1;

         // shiftX - Сдвиг по X между началом отображения сетки и окна secondWindow
        private int shiftX = 0;
        // shiftY - Сдвиг по Y между началом отображения сетки и окна secondWindow
        private  int shiftY = 0;

        // shiftGridX - Сдвиг сетки по X относительно Контура помещения
        private int shiftGridX = 0;
        // shiftGridY - Сдвиг сетки по Y относительно Контура помещения
        private  int shiftGridY = 0;

        //windowWidth - ширина окна X- рх
        private int windowWidth = 1208;
        //windowHeight - высота окна Y- рх
        private int windowHeight = 860;
        // sing - Синус угла поворота
        // private double sing = 0;
        private  double sing = Math.sin(angleRotation);
        //  cosg - Косинус угла поворота
        //private double cosg = 1;
        private double cosg = Math.cos(angleRotation);
        //  tgg - Tангенс угла поворота g
        private double tgg = 0;
        //  ctgg -Kotангенс угла поворота g
        private double ctgg = 0;


        public int getTileWidth() {
            return tileWidth;
        }

        public int getTileHeight() {
            return tileHeight;
        }

        public int getTileSeam() {
            return tileSeam;
        }

        public int getBiasX() {
            return biasX;
        }

        public int getBiasY() {
            return biasY;
        }

        public double getScale() {
            return scale;
        }

        public double getAngleRotation() { return angleRotation;  }
        public double getSing() {return sing;}
        public double getCosg() {return cosg;}

        public void setTileWidth(int tileWidth) {
            this.tileWidth = tileWidth;
            // this.tileWidth=tW;
        }

        public void setTileHeight(int tileHeight) {
            this.tileHeight = tileHeight;
            //this.tileHeight = tH;
        }

        public void setTileSeam(int tileSeam) {
            this.tileSeam = tileSeam;
            //this.tileSeam = tS;
        }

        public void setBiasX(int bX) {
            this.biasX = bX;

            //this.biasX = bX;
        }

        public void setBiasY(int biasY) {
            this.biasY = biasY;
            //this.biasY =bY;
        }

        public void setScale(double scale) {
            this.scale = scale;
            //this.scale = sc;
        }

        public void setSing(double sing) {
            sing = Math.sin(angleRotation);
            //this.sing = sing;
        }

        public void setCosg(double cosg) {
            cosg = Math.cos(angleRotation);
            //this.cosg = cosg;
        }

        public void setTgg(double tgg) {
            tgg = Math.tan(angleRotation);
        }

        public void setCtgg(double ctgg) {
            ctgg = 1 / tgg;
        }


        public void setAngleRotation(double angleRotation) {
            this.angleRotation = angleRotation;
            if (angleRotation < 0.000001) {
                this.angleRotation = 0;
            }
            sing = StrictMath.sin(angleRotation);
            cosg = StrictMath.cos(angleRotation);
            if (sing < 0.00001) {
                sing = 0;
                cosg = 1;
            }
            if (cosg < 0.00001) {
                sing = 1;
                cosg = 0;
            }

            if (angleRotation > 1.57) {
                this.angleRotation = 1.57;
            }

        }


        public GridP() {
        }

        public GridP(int tileWidth, int tileHeight, int tileSeam) {
            this.tileWidth = tileWidth;
            this.tileHeight = tileHeight;
            this.tileSeam = tileSeam;
        }

        public GridP(int biasX, int biasY) {
            this.biasX = biasX;
            this.biasY = biasY;
        }

        public GridP(double angleRotation) {
            this.angleRotation = angleRotation;
        }

        public GridP(int tileWidth, int tileHeight, int tileSeam, double scale) {
            this.tileWidth = tileWidth;
            this.tileHeight = tileHeight;
            this.tileSeam = tileSeam;
            this.scale = scale;
        }

        public GridP(int tileWidth, int tileHeight, int tileSeam, double scale, double angleRotation, int biasY, int biasX) {
            this.tileWidth = tileWidth;
            this.angleRotation = angleRotation;
            this.scale = scale;
            this.biasY = biasY;
            this.biasX = biasX;
            this.tileSeam = tileSeam;
            this.tileHeight = tileHeight;
        }


        public void makeGridDraw() {
            //  LineDelite.deliteOll ();
            CleanPane cleanPane = new CleanPane();
            cleanPane.deliteOll();

            // приводим к масштабу
            int tileWidthScale = (int) ((tileWidth + tileSeam) * scale);
            int tileHeightScale = (int) ((tileHeight + tileSeam) * scale);
            int tileSeamScale = 1;
            int tileSeamScale01 = (int) (tileSeam * scale);
            if (tileSeamScale01 < 1) {
                tileSeamScale = 1;
            }
            if (tileSeamScale01 > 1) {
                tileSeamScale = tileSeamScale01;
            }

            if (angleRotation == 0) {
                // numX - ко-во линий по оси Х
                // numY - ко-во линий по оси У
                // biasX*scale biasY*scale -?

                // Некорректированная версия
//                int numX = (int) ((1208 - biasX*scale) / tileWidthScale);
//                int numY = (int) ((860 - biasY*scale) / tileHeightScale);
//                int i, j;
//                for (i = 0; i <= numX; i++) {
//                    int X1 = (int) (biasX*scale + i * tileWidthScale);
//                    int X2 = (int) (biasX*scale + i * tileWidthScale);

//                    LineDraw line00i = new LineDraw(X1, 0, X2, 860);
//                    line00i.lineDraw();
//                }
//                for (j = 0; j <= numY; j++) {
//                    LineDraw line00j = new LineDraw(0, (((int)(biasY*scale)) + j * tileHeightScale),
//                                                 1208, (((int)(biasY*scale)) + j * tileHeightScale));
//                    line00j.lineDraw();
//                }
//
//            }

            int numX = (int) ((1208 - biasX*scale - X0) / tileWidthScale);
            int numY = (int) ((860 - biasY*scale) - Y0 / tileHeightScale);
            int i, j;
            for (i = 0; i <= numX; i++) {

                int X1 = (int) (biasX*scale + i * tileWidthScale + X0);
                int X2 = (int) (biasX*scale + i * tileWidthScale + X0);

                LineDraw line00i = new LineDraw(X1, + Y0, X2, 860);
                line00i.lineDraw();
            }
            for (j = 0; j <= numY; j++) {

                LineDraw line00j = new LineDraw( X0, (((int)(biasY*scale)) + j * tileHeightScale + Y0),
                                                1208, (((int)(biasY*scale)) + j * tileHeightScale + Y0));
                line00j.lineDraw();

//                    System.out.println("\n  angleRotation = 0,  X0 = " + X0);
//                    System.out.println("\n  angleRotation = 0,  Y0 = " + Y0);


            }

        }
            if (!(angleRotation == 0)) {


                //public void setSing(double sing) {
                sing = Math.sin(angleRotation);
                //this.sing = sing;
                //}

                // public void setCosg(double cosg) {
                cosg = Math.cos(angleRotation);
                //this.cosg = cosg;
                //}

                //public void setTgg(double tgg) {
                tgg = Math.tan(angleRotation);
                // }
                // public void setCtgg(double ctgg) {
                ctgg = 1 / tgg;

                double hypotenuse = 860 / sing;

                // d - шаг сетки по оси Х
                // е - шаг сетки по оси У
                double d = tileWidthScale / sing;
                double e = tileHeightScale / sing;

                // numX - ко-во линий по оси Х
                // numY - ко-во линий по оси У
//                int numX = (int) ((1208 - biasX) / d);
//                int numY = (int) ((860 - biasY) / e);

                int numX = (int) ((1208 - biasX - X0) / d);
                int numY = (int) ((860  - biasY - Y0) / e);

                    System.out.println("Количество линий исходное (int) ((1208 - biasX) / d: " + (int) ((1208 - biasX) / d));
                    System.out.println("Количество линий скорректированное (int) ((1208 - biasX + X0) / d: " + (int) ((1208 - biasX - X0) / d));
                    System.out.println("\n  *X0 :" + X0);
                    System.out.println("\n  *biasX :" + biasX);

//                int i, j;
//                for (i = 0; i <= numX; i++) {
//
//                    if ((biasX + i * d + 860 * ctgg) < 1208) {
//                        LineDraw line00i = new LineDraw((int) (biasX + i * d), 0,
//                                                        (int) (biasX + i * d + 860 * ctgg), 860);
//                        line00i.lineDraw();
//                    } else {
//                        LineDraw line00ii = new LineDraw((int) (biasX + i * d), 0,
//                                                         1208, (int) (860 - (((biasX + i * d + 860 * ctgg) - 1208) * tgg)));
//                        line00ii.lineDraw();
//                    }
//
//
//                }

                int i, j;
                for (i = 0; i <= numX; i++) {

                    if ((biasX + i * d + (860 - Y0) * ctgg) <= 1208 - X0) {

                        LineDraw line00i = new LineDraw((int) (biasX + i * d) + X0, Y0,
                                                        (int) (biasX + i * d  + X0 + (860 - Y0) * ctgg) , 860);
                           System.out.println("\nX0:" + X0);
                           System.out.println("\nY0:" + Y0);

                        line00i.lineDraw();


                    } else {
                       LineDraw line00ii = new LineDraw((int) (biasX + i * d) + X0, Y0,
                                                        1208, (int) (860  - (((biasX + i * d + (860 - Y0)  * ctgg) - (1208 - X0)) * tgg)));
                        line00ii.lineDraw();
                    }


                }



                int x, x01, x03, y01, y02, y03;

                for (i = 0; (int) (tgg * (i * d - biasX)) <= 860 - Y0; i++) {

//                    x03 = (int) (i * d - biasX);
//                    y03 = (int) (x03 * tgg);
//
//                    x = (int) ((860 - y03) / tgg);


                    x03 = (int) (i * d - biasX);
                    y03 = (int) (x03 * tgg);

                    x = (int) ((860 - Y0 - y03) / tgg);

                    if (x > 1208 - X0) {
//                        x01 = x - 1208;
//                        y02 = (int) (x01 * tgg);
//                        y01 = 860 - y02;
//
                        x01 = x - 1208 + X0;
                        y02 = (int) (x01 * tgg);
                        y01 = 860 - y02;

                        LineDraw line00i = new LineDraw(X0, Y0 + y03, 1208, y01);
                        line00i.lineDraw();

                    }

                    if (x <= 1208 - X0) {

//                        int x04 = x;
//                        LineDraw line00i = new LineDraw(0, y03, x04, 860);
//                        line00i.lineDraw();
//

                        int x04 = x;
                        LineDraw line00i = new LineDraw(X0, Y0 + y03, x04 + X0, 860);
                        line00i.lineDraw();
                    }


                }

                //g2 - угол, (дополнительный к углу поворота) angleRotation .
                // double g2 = ((Math.PI)/2 - angleRotation);

                double g2 = angleRotation;
                double cosg2 = Math.cos(g2);

                //// double e = cosg2*tileHeightScale;
                //// double e = tileHeightScale/sing2;

//                int    num_Y  = (int) ((860 - biasY) / e);
//                double sing2  = Math.sin(g2);
//                double cos_g2 = Math.cos(g2);
//                double tgg2   = Math.tan(g2);
//                double ctgg2  = 1 / Math.tan(g2);
//                double tgg3   = Math.tan(((Math.PI) / 2) - g2);
//                double X;

                int    num_Y  = (int) ((860 - Y0 - biasY) / e);
                double sing2  = Math.sin(g2);
                double cos_g2 = Math.cos(g2);
                double tgg2   = Math.tan(g2);
                double ctgg2  = 1 / Math.tan(g2);
                double tgg3   = Math.tan(((Math.PI) / 2) - g2);
                double X;

                int l = 0;

//                for (l = 0; l <= num_Y; l++) {
//
//                    int yl = (int) (biasY + l * e);
//                    //int xl = (int) (yl*tgg2);
//                    //int xl = (int) (yl*tgg2);
//                    int xl = (int) (yl * tgg2);
//
//                    if (xl <= 1208) {

                for (l = 0; l <= num_Y; l++) {

                    int yl = (int) (biasY + l * e );
                    //int xl = (int) (yl*tgg2);
                    //int xl = (int) (yl*tgg2);
                    int xl = (int) (yl * tgg2);

                    // 5 группа:

                    if (xl <= 1208 - X0) {

//                        LineDraw lineDrawl = new LineDraw(0, yl, xl, 0);
//                        lineDrawl.lineDraw();

                        LineDraw lineDrawl = new LineDraw(X0, yl + Y0, xl + X0, Y0);
                        lineDrawl.lineDraw();

//


//                    } else {
//                        X = tgg2 * yl;
//                        int x05 = (int) (X - 1208);
//                        int yl2 = (int) (tgg3 * x05);

                    } else {

                        // 6 группа:

                        X = tgg2 * yl;
                        int x05 = (int) (X - 1208 + X0);
                        int yl2 = (int) (tgg3 * x05);

//                        LineDraw lineDrawl = new LineDraw(0, yl, 1208, yl2);
//                        lineDrawl.lineDraw();

                        LineDraw lineDrawl = new LineDraw(X0, yl + Y0, 1208, yl2 + Y0);
                        lineDrawl.lineDraw();




                    }
                }



//                int k = 0;
//
//                for (k = 1; (((k + num_Y) * e + biasY) - 860) * tgg2 <= 1208; k++) {
//                    double y11 = ((k + num_Y) * e + biasY);
//                    double y10 = y11 - 860;
//
//                    int x10 = (int) (y10 * tgg2);
//                    double x11 = tgg2 * y11;
//

                int k = 0;

                for (k = 1; (((k + num_Y) * e + biasY) - 860 + Y0) * tgg2 <= 1208 - X0; k++) {
                    double y11 = ((k + num_Y) * e + biasY);
                    double y10 = y11 - 860 + Y0;

                    int x10 = (int) (y10 * tgg2);
                    double x11 = tgg2 * y11;

                      // 7 группа

//                    if (x11 < 1208) {
//
//                        if (x11 < 1208) {
//                            int x14 = (int) x11;

                    if (x11 < 1208 - X0) {

                        if (x11 < 1208 - X0) {
                            int x14 = (int) x11;

//                            LineDraw lineDrawl = new LineDraw(x10, 860, x14, 0);
//                            lineDrawl.lineDraw();

                            LineDraw lineDrawl = new LineDraw(x10 + X0, 860, x14 + X0, Y0);
                            lineDrawl.lineDraw();

                        }
                    }

                    // 8 группа

                    if (x11 >= 1208 - X0) {
                        double x12 = x11 - 1208 + X0;
                        int y12 = (int) (tgg3 * x12);


//                        LineDraw lineDrawl = new LineDraw(x10, 860, 1208, y12);
//                        lineDrawl.lineDraw();

                        LineDraw lineDrawl = new LineDraw(x10 + X0, 860, 1208, y12 + Y0);
                        lineDrawl.lineDraw();
                    }


                }


            }


        }


    }

    class LineDraw implements LineEdit {

        private int startX = 0;
        private int startY = 0;
        private int endX = 1208;
        private int endY = 858;
        private int strokeWidth = 2;
        private Color stroke = Color.BLUE;

        public int getStartX() {
            return startX;
        }

        public int getStartY() {
            return startY;
        }

        public int getEndX() {
            return endX;
        }

        public int getEndY() {
            return endY;
        }

        public int getStrokeWidth() {
            return strokeWidth;
        }

        public Color getStroke() {
            return stroke;
        }

        public void setStartX(int startX) {
            this.startX = startX;
        }

        public void setStartY(int startY) {
            this.startY = startY;
        }

        public void setEndX(int endX) {
            this.endX = endX;
        }

        public void setEndY(int endY) {
            this.endY = endY;
        }

        public void setStrokeWidth(int strokeWidth) {
            this.strokeWidth = strokeWidth;
        }

        public void setStroke(Color stroke) {
            this.stroke = stroke;
        }

        public LineDraw(int startX, int startY, int endX, int endY, int strokeWidth, Color stroke) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
            this.strokeWidth = strokeWidth;
            this.stroke = stroke;
        }

        public LineDraw(int strokeWidth, Color stroke) {
            this.stroke = stroke;
            this.strokeWidth = strokeWidth;
        }

        public LineDraw(int startX, int startY, int endX, int endY) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
        }

        public void lineDraw() {
            Line lineStart = new Line();
            lineStart.setStartX(startX);
            lineStart.setStartY(startY);
            lineStart.setEndX(endX);
            lineStart.setEndY(endY);
            lineStart.setStrokeWidth(strokeWidth);
            lineStart.setStroke(stroke);
            paneMain.getChildren().add(lineStart);
        }
    }

    public void methodLineDraw(int startX, int startY, int endX, int endY, int strokeWidth, Color stroke ){
        Line lineStart = new Line();
        lineStart.setStartX(startX);
        lineStart.setStartY(startY);
        lineStart.setEndX(endX);
        lineStart.setEndY(endY);
        lineStart.setStrokeWidth(strokeWidth);
        lineStart.setStroke(stroke);
        paneMain.getChildren().add(lineStart);


    }

}
