package com.yuri;

public class StartPointElementsCollection {

    private int startPointElementsCollectionX = 0;
    private int startPointElementsCollectionY = 0;

    public StartPointElementsCollection(int startPointElementsCollectionX, int startPointElementsCollectionY) {
        this.startPointElementsCollectionX = startPointElementsCollectionX;
        this.startPointElementsCollectionY = startPointElementsCollectionY;
    }

    public StartPointElementsCollection() {}

    public static StartPointElementsCollection instance = null;

    public static StartPointElementsCollection getInstance() {
        if (instance == null) instance = new StartPointElementsCollection();

        return instance;
    }

    public int getStartPointElementsCollectionX() {
        return startPointElementsCollectionX;
    }

    public void setStartPointElementsCollectionX(int startPointElementsCollectionX) {
        this.startPointElementsCollectionX = startPointElementsCollectionX;
    }

    public int getStartPointElementsCollectionY() {
        return startPointElementsCollectionY;
    }

    public void setStartPointElementsCollectionY(int startPointElementsCollectionY) {
        this.startPointElementsCollectionY = startPointElementsCollectionY;
    }


}
