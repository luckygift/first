package com.yuri;

import javafx.scene.control.Alert;

public class WindowErrorNumberFormat {

    public WindowErrorNumberFormat() { }

    protected void show() {

           System.out.println("000 Не верный формат ввода числа");

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("coverdesigner");
        alert.setHeaderText("Invalid format entered.");
        alert.setContentText("Try again!");
        alert.showAndWait();
    }
}
